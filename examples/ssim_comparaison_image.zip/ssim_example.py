# -*- coding: utf-8 -*-
"""
Created on Sat Mar 31 22:20:30 2018

@author: blook
"""

from skimage.measure import compare_ssim as ssim
import cv2

imageA = cv2.imread("cercle_model.png")
imageB = cv2.imread("cercle_blanc.png")

print(ssim(imageA, imageB, multichannel=True))
